package com.example.clt;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.app.ProgressDialog;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;

import static android.media.CamcorderProfile.get;
import static android.widget.Toast.LENGTH_LONG;

public class Tabtwo extends AppCompatActivity{
    ArrayList<Product> arrayList;
    ListView lv;
    ProgressDialog pd;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tabtwo);
        arrayList = new ArrayList<>();
        lv=(ListView)  findViewById(R.id.ListView);



       // new Jsontask().execute("https://jsonware.com/json/1663dac7014c2cffaadf3af2787c8cbc.json");
        new Tabtwo.JsonTask().execute("https://jsonware.com/json/b548e58352d5c0f647500f8b47865b6e.json");

    }



    private class JsonTask extends AsyncTask<String, String, String> {

        protected void onPreExecute() {
            super.onPreExecute();

            pd = new ProgressDialog(Tabtwo.this);
            pd.setMessage("Please wait");
            pd.setCancelable(false);
            pd.show();
        }

        @RequiresApi(api = Build.VERSION_CODES.KITKAT)
        @SuppressLint("WrongThread")
        protected String doInBackground(String... params) {


            HttpURLConnection connection = null;
            BufferedReader reader = null;

            try {
                URL url = new URL(params[0]);
                connection = (HttpURLConnection) url.openConnection();
                connection.connect();


                InputStream stream = connection.getInputStream();

                reader = new BufferedReader(new InputStreamReader(stream));

                StringBuffer buffer = new StringBuffer();
                String line = "";

                while ((line = reader.readLine()) != null) {
                    buffer.append(line+"\n");
                    try {
                        JSONObject obj = new JSONObject(line);


                        JSONArray pl=obj.getJSONArray("grounds");

                        for (int i=0;i<pl.length();i++){
                            JSONObject single=pl.getJSONObject(i);
                            arrayList.add(new Product(
                                    single.getString("url"),
                                    single.getString("name"),
                                    single.getString("place")


                            ));

                        }
                        Log.d("datetime", String.valueOf(arrayList));
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }

                }

                return buffer.toString();

            } catch (MalformedURLException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            } finally {
                if (connection != null) {
                    connection.disconnect();
                }
                try {
                    if (reader != null) {
                        reader.close();
                    }
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
            return null;
        }

        @Override
        protected void onPostExecute(String result) {
            super.onPostExecute(result);
            if (pd.isShowing()){
                pd.dismiss();
            }


            CustomListAdapter india=new CustomListAdapter(Tabtwo.this,arrayList);
            lv.setAdapter(india);


        }
    }




}