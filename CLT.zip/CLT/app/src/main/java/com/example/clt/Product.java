package com.example.clt;

public class Product {

    private String image;
    private  String  name;
    private  String bdate;

    public Product(String image, String name, String bdate) {
        this.image = image;
        this.name = name;
        this.bdate = bdate;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getBdate() {
        return bdate;
    }

    public void setBdate(String bdate) {
        this.bdate = bdate;
    }
}



  
