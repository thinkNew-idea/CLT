package com.example.clt;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.app.ProgressDialog;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;

public class Tabthree extends AppCompatActivity {
    ArrayList<Product> arrayList;
    ListView lv;
ProgressDialog pd;
Button b1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tabthree);
        arrayList = new ArrayList<>();
        lv=(ListView)  findViewById(R.id.ListView);




        final String s = "https://jsonware.com/json/b548e58352d5c0f647500f8b47865b6e.json";
        new JsonTask().execute(s);


    }
  private   class JsonTask extends AsyncTask<String, String, String> {

        protected void onPreExecute() {
            super.onPreExecute();

            pd = new ProgressDialog(Tabthree.this);
            pd.setMessage("Please wait");
            pd.setCancelable(false);
            pd.show();
        }

        @RequiresApi(api = Build.VERSION_CODES.KITKAT)
        @SuppressLint("WrongThread")
        protected String doInBackground(String... params) {


            HttpURLConnection connection = null;
            BufferedReader reader = null;

            try {
                URL url = new URL(params[0]);
                connection = (HttpURLConnection) url.openConnection();
                connection.connect();


                InputStream stream = connection.getInputStream();

                reader = new BufferedReader(new InputStreamReader(stream));

                StringBuffer buffer = new StringBuffer();
                String line = "";

                while ((line = reader.readLine()) != null) {
                    buffer.append(line+"\n");
                    try {
                        JSONObject obj = new JSONObject(line);


                        JSONArray pl=obj.getJSONArray("matches");

                        for (int i=0;i<pl.length();i++){
                            JSONObject single=pl.getJSONObject(i);
                            arrayList.add(new Product(
                                    single.getString("url"),
                                    single.getString("matche"),
                                    single.getString("Deatils")


                            ));

                        }
                        Log.d("datetime", String.valueOf(arrayList));
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }

                }

                return buffer.toString();

            } catch (MalformedURLException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            } finally {
                if (connection != null) {
                    connection.disconnect();
                }
                try {
                    if (reader != null) {
                        reader.close();
                    }
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
            return null;
        }

        @Override
        protected void onPostExecute(String result) {
            super.onPostExecute(result);
            if (pd.isShowing()){
                pd.dismiss();
            }


            CustomListAdapter india=new CustomListAdapter(Tabthree.this,arrayList);
            lv.setAdapter(india);






        }
    }

}