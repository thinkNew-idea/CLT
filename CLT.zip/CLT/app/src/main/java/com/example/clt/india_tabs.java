package com.example.clt;

import androidx.appcompat.app.AppCompatActivity;

import android.app.TabActivity;
import android.content.Intent;
import android.os.Bundle;
import android.widget.TabHost;

public class india_tabs extends TabActivity {
    TabHost TabHostWindow;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_india_tabs);
        TabHostWindow = (TabHost)findViewById(android.R.id.tabhost);

        TabHost.TabSpec TabMenu1 = TabHostWindow.newTabSpec("First tab");
        TabHost.TabSpec TabMenu2 = TabHostWindow.newTabSpec("Second Tab");
        TabHost.TabSpec TabMenu3 = TabHostWindow.newTabSpec("Third Tab");


        TabMenu1.setIndicator("Players");
        TabMenu1.setContent(new Intent(this,Tabone.class));
        TabMenu2.setIndicator("Venue");
        TabMenu2.setContent(new Intent(this,Tabtwo.class));
        TabMenu3.setIndicator("Matches");
        TabMenu3.setContent(new Intent(this,Tabthree.class));



        TabHostWindow.addTab(TabMenu1);
        TabHostWindow.addTab(TabMenu2);
        TabHostWindow.addTab(TabMenu3);
    }
}