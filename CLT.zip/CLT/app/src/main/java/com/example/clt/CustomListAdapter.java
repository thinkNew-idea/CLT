package com.example.clt;

import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.squareup.picasso.Picasso;

import java.util.ArrayList;
import java.util.List;
import java.util.ListIterator;

public class CustomListAdapter extends BaseAdapter {
private  Context context ;
 List<Product> products;
Dialog dialog;
    Button b1;

    public CustomListAdapter(Context context,List<Product> products) {
  this.context=context;
  this.products=products;
    }

    @Override
    public int getCount() {
        return products.size();
    }

    @Override
    public Object getItem(int position) {
        return products.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(final int position, View convertView, ViewGroup parent) {
       final Product thisProduct=products.get(position);
       if (convertView==null){
           convertView=LayoutInflater.from(context).inflate(R.layout.custom_list_layout,parent,false);
           ImageView imageView = convertView.findViewById(R.id.imageViewProduct);
           TextView name = convertView.findViewById(R.id.txtName);
           TextView bdate = convertView.findViewById(R.id.txtbday);
          // TextView work = convertView.findViewById(R.id.txtwork);
           name.setText(thisProduct.getName());
           bdate.setText(thisProduct.getBdate());
//work.setText(thisProduct.getWork());


          if (thisProduct.getImage().length()>0 && thisProduct.getImage()!=null)
           {
               Picasso.get().load(thisProduct.getImage()).placeholder(R.drawable.loading).into(imageView);
           }else {
               Toast.makeText(context, "Empty Image URL", Toast.LENGTH_LONG).show();
               Picasso.get().load(R.drawable.loading).into(  imageView);
           }

          convertView.setOnClickListener(new View.OnClickListener() {
              @Override
              public void onClick(View v) {

                  dialog=new Dialog(context);
                  dialog.setContentView(R.layout.popup);
                  TextView pname=(TextView) dialog.findViewById(R.id.pname);
                  TextView pbdate = (TextView) dialog.findViewById(R.id.pbdate);
                  ImageView pim=(ImageView) dialog.findViewById(R.id.pupimges);
                  pname.setText(thisProduct.getName());
                  pbdate.setText(thisProduct.getBdate());

                  if(thisProduct.getImage() != null &&thisProduct.getImage().length()>0)
                  {
                      Picasso.get().load(thisProduct.getImage()).placeholder(R.drawable.loading).into(pim);
                  }else {
                      Toast.makeText(context, "Empty Image URL", Toast.LENGTH_LONG).show();
                      Picasso.get().load(R.drawable.loading).into(pim);
                  }

                  dialog.show();


              }
          });




       }

        return convertView;
    }
}
